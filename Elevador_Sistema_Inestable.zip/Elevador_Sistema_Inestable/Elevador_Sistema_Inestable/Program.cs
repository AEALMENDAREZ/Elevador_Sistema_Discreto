﻿using System;

// Ariel Almendárez - 1074625
// Livi Escobar - 1264425
// Bernardette Aragón - 1265425
class Elevador
{
    static int capacidadElevador = 10;
    static Random random = new Random();

    static public bool Libre(int numeroPersonas)
    {
        // La capacidad del elevador se vuelve aleatoria.
        capacidadElevador += random.Next(-3, 5);

        // Las condiciones devuelven lo contrario a lo que deberían
        if (numeroPersonas > capacidadElevador)
        {
            return true;
        }
        else
        {
            int numero = random.Next(0, 2); // Devuelve un estado aleatorio.
            if (numero == 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
    }

    static public string estadoElevador(bool libre)
    {
        // Si el elevador está "Libre", se devuelve el estado contrario.
        if (libre)
        {
            return "OCUPADO";
        }
        else
        {
            return "LIBRE";
        }
    }

    static void Main()
    {
        int numeroPersonas = 0;

        Console.WriteLine("Sistema Elevador (Inestable)");
        Console.WriteLine("");

        // El bucle NO tiene condición de salida.
        while (true)
        {
            // Se genera un número aleatorio de personas que entran al elevador.
            int personasEntrando = random.Next(1, 6);
            numeroPersonas += personasEntrando;

            Console.WriteLine("Entran " + personasEntrando + " personas.");
            Console.WriteLine("Personas actuales: " + numeroPersonas);
            Console.WriteLine("Capacidad actual: " + capacidadElevador);
            Console.WriteLine("Estado reportado: " + estadoElevador(Libre(numeroPersonas)));
            Console.WriteLine("");

            // Contador para que el programa no se cierre instantáneamente
            System.Threading.Thread.Sleep(1000);
        }
    }
}
